These fonts are provided as-is - they may not be 100% accurate.  If you don't like them, don't use them, it's that simple.

To install them, simply copy them into your fonts folder (usually c:\windows\fonts) and enjoy.

Questions & comments?  eriqjaffe@hotmail.com

Big thanks to Kirk Baethke (kbaethke@gmail.com) for the 2006 Ducks & Sabres fonts!